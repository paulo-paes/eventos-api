import React, { useEffect, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import constantes from './constantes';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';

const Login: React.FC = () => {
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [error, setError] = useState<boolean>(false);
  const navigate = useNavigate()

  useEffect(() => {
    const token = localStorage.getItem(constantes.TOKEN_KEY) as string

    if (token?.length) {
      navigate("/events")
    }
  }, [navigate])

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(e.target.value);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!email?.length || !password?.length) {
      setError(true)
      return
    }
    const body = {
      email,
      senha: password
    }
    const res = await fetch(constantes.BASE_URL + 'login', {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body)
    })

    if (res.ok) {
      const responseBody = await res.json()
      localStorage.setItem(constantes.TOKEN_KEY, responseBody.token)
      navigate("/events")
    } else {
      setError(true)
    }
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card">
            <div className="card-header">Login</div>
            <div className="card-body">
              <form onSubmit={handleSubmit}>
                <div className="form-group mt-3">
                  <label htmlFor="email">Email</label>
                  <input
                    type="email"
                    className="form-control"
                    id="email"
                    placeholder="examplo@examplo.com"
                    value={email}
                    onChange={handleEmailChange}
                    required
                  />
                </div>
                <div className="form-group mt-3">
                  <label htmlFor="password">Senha</label>
                  <input
                    type="password"
                    className="form-control"
                    id="password"
                    placeholder="senha"
                    value={password}
                    onChange={handlePasswordChange}
                    required
                  />
                </div>
                {
                  error && <div className='text-danger'>Email ou senha inválidos!</div>
                }
                <button type="submit" className="btn btn-primary btn-block mt-3">
                  Login
                </button>
              </form>

              <div className="mt-3 text-center">
                <Link to="/register">
                  <span>Não tem uma conta? Cadastre-se</span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Login;
