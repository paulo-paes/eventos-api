export default {
  BASE_URL: 'http://localhost:3000/',
  TOKEN_KEY: 'TOKEN'
}
