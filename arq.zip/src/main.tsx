import ReactDOM from 'react-dom/client'
import './index.css'
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import Login from './Login';
import Register from './Register';
import Events from './Event';
import Orders from './Order';
import CreateEvent from './CreateEvent';

const router = createBrowserRouter([
  {
    path: "/",
    Component: Login,
  },
  {
    path: "/register",
    Component: Register
  },
  {
    path: "/events",
    Component: Events
  },
  {
    path: "/orders",
    Component: Orders
  },
  {
    path: "/create-event",
    Component: CreateEvent
  }
]);

ReactDOM.createRoot(document.getElementById('root')!).render(
  <RouterProvider router={router} />,
)
