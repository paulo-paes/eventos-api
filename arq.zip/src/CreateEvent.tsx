import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Auth } from "./Auth";
import constantes from "./constantes";
import { useNavigate } from "react-router-dom";
import { Navbar } from "./Navbar";

const CreateEvent: React.FC = () => {
  const navigate = useNavigate()
  const [titulo, setTitulo] = useState<string>("");
  const [descricao, setDescricao] = useState<string>("");
  const [dataInicio, setDataInicio] = useState<string>("");
  const [dataFim, setDataFim] = useState<string>("");
  const [preco, setPreco] = useState<string>("");
  const [totalIngressos, setTotalIngressos] = useState<number>(0);

  const handleTituloChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTitulo(e.target.value);
  };

  const handleDescricaoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDescricao(e.target.value);
  };

  const handleDataInicioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDataInicio(e.target.value);
  };

  const handleDataFimChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDataFim(e.target.value);
  };

  const handlePrecoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPreco(e.target.value);
  };

  const handleTotalIngressosChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    setTotalIngressos(Number(e.target.value));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const event = {
      titulo,
      descricao,
      dataInicio: new Date(dataInicio).toISOString(),
      dataFim: new Date(dataFim).toISOString(),
      preco,
      totalIngressos,
    };
    
    const res = await fetch(constantes.BASE_URL + 'events', {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + localStorage.getItem(constantes.TOKEN_KEY)
      },
      body: JSON.stringify(event)
    })

    if (res.ok) {
      alert('Evento criado com sucesso!')
      navigate('/')
    } else {
      alert('não foi possível criar o evento')
    }
  };

  return (
    <Auth>
      <Navbar />
      <div className="container mt-5">
        <div className="row justify-content-center">
          <div className="col-md-6">
            <div className="card">
              <div className="card-header">Criar evento</div>
              <div className="card-body">
                <form onSubmit={handleSubmit}>
                  <div className="form-group mt-2">
                    <label htmlFor="titulo">Titulo</label>
                    <input
                      type="text"
                      className="form-control"
                      id="titulo"
                      placeholder="Titulo"
                      value={titulo}
                      onChange={handleTituloChange}
                      required
                    />
                  </div>
                  <div className="form-group mt-2">
                    <label htmlFor="descricao">Descrição</label>
                    <input
                      type="text"
                      className="form-control"
                      id="descricao"
                      placeholder="Descrição"
                      value={descricao}
                      onChange={handleDescricaoChange}
                      required
                    />
                  </div>
                  <div className="form-group mt-2">
                    <label htmlFor="dataInicio">Início</label>
                    <input
                      type="datetime-local"
                      className="form-control"
                      id="dataInicio"
                      value={dataInicio}
                      onChange={handleDataInicioChange}
                      required
                    />
                  </div>
                  <div className="form-group mt-2">
                    <label htmlFor="dataFim">Fim</label>
                    <input
                      type="datetime-local"
                      className="form-control"
                      id="dataFim"
                      value={dataFim}
                      onChange={handleDataFimChange}
                      required
                    />
                  </div>
                  <div className="form-group mt-2">
                    <label htmlFor="preco">Preço</label>
                    <input
                      type="text"
                      className="form-control"
                      pattern="^\d+(\.\d{1,2})?$"
                      id="preco"
                      placeholder="10.99"
                      value={preco}
                      onChange={handlePrecoChange}
                      required
                    />
                  </div>
                  <div className="form-group mt-2">
                    <label htmlFor="totalIngressos">Total de Ingressos</label>
                    <input
                      type="number"
                      className="form-control"
                      id="totalIngressos"
                      placeholder="Total de Ingressos"
                      value={totalIngressos}
                      onChange={handleTotalIngressosChange}
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    className="btn btn-success btn-block mt-3"
                  >
                    Cadastrar
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Auth>
  );
};

export default CreateEvent;
