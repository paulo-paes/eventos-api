import { useEffect } from "react"
import constantes from "./constantes"
import { useNavigate } from "react-router-dom"

type Props = {
  children?: React.ReactNode
}

export const Auth: React.FC<Props> = ({ children }: Props) => {
  const navigate = useNavigate()

  useEffect(() => {
    const token = localStorage.getItem(constantes.TOKEN_KEY)
    if (!token) {
      navigate('/')
    }
  }, [navigate])

  return <>{ children }</>
  
}