import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Auth } from "./Auth";
import constantes from "./constantes";
import { Navbar } from "./Navbar";

interface Order {
  idEvento: string;
  quantidade: number;
  valorTotal: string;
  dataPedido: string;
  nomeEvento: string;
}

// const orders: Order[] = [
//   {
//     idEvento: "0c64c8d7-95f3-45b7-a96f-3e890a2ddf38",
//     quantidade: 3,
//     valorTotal: "30",
//     dataPedido: "2024-06-15T17:59:39.149Z",
//   },
//   // You can add more orders here
// ];

const Orders: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);

  const getOrders = async () => {
    const res = await fetch(constantes.BASE_URL + "order", {
      headers: {
        Authorization: "Bearer " + localStorage.getItem(constantes.TOKEN_KEY),
      },
    });

    if (res.ok) {
      const orders = await res.json();
      setOrders(orders);
    }
  }

  useEffect(() => {
    getOrders()
  }, [])

  return (
    <Auth>
      <Navbar />
      <div className="container mt-5">
        <div className="row">
          <div className="col-md-12">
            <h2>Pedidos</h2>
            {orders.map((order, index) => (
              <div key={index} className="card mb-3">
                <div className="card-body">
                  <p className="card-text">
                    <strong>Nome evento:</strong> {order.nomeEvento}
                  </p>
                  <p className="card-text">
                    <strong>Quantidade:</strong> {order.quantidade}
                  </p>
                  <p className="card-text">
                    <strong>Valor total:</strong> R${order.valorTotal}
                  </p>
                  <p className="card-text">
                    <small className="text-muted">
                      Data do pedido: {new Date(order.dataPedido).toLocaleString('pt-BR')}
                    </small>
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Auth>
  );
};

export default Orders;
