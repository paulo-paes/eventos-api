import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import constantes from "./constantes";
import { Auth } from "./Auth";
import { Navbar } from "./Navbar";

interface Event {
  titulo: string;
  descricao: string;
  dataCriacao: string;
  dataInicioEvento: string;
  dataFimEvento: string;
  preco: string;
  totalIngressos: number;
  id: string;
}


const Events: React.FC = () => {
  const [showModal, setShowModal] = useState<boolean>(false);
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [quantity, setQuantity] = useState<number>(1);
  const [events, setEvents] = useState<Event[]>([]);

  useEffect(() => {
    getEvents();
  }, []);

  const getEvents = async () => {
    const res = await fetch(constantes.BASE_URL + "events", {
      headers: {
        Authorization: "Bearer " + localStorage.getItem(constantes.TOKEN_KEY),
      },
    });

    if (res.ok) {
      const events = await res.json();
      setEvents(events);
    }
  };

  const handleShowModal = (eventId: string) => {
    setSelectedEventId(eventId);
    setShowModal(true);
  };


  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedEventId(null);
    setQuantity(1);
  };

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setQuantity(Number(e.target.value));
  };

  const handleBookTicket = async () => {
    if (selectedEventId) {
      const body = {
        idEvento: selectedEventId,
        quantidade: quantity,
      };
      const res = await fetch(constantes.BASE_URL + 'order', {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + localStorage.getItem(constantes.TOKEN_KEY)
        },
        body: JSON.stringify(body)
      });

      if (res.ok) {
        alert('Ingresso comprado com sucesso!')
        getEvents();
      } else {
        alert('Não foi possível completar a transação')
      }
      handleCloseModal();
    }
  };

  return (
    <Auth>
      <Navbar />
      <div className="container mt-5">
        <div className="row">
          <div className="col-md-12">
            <h2 className="mb-3">Eventos</h2>
            {events.map((event) => (
              <div key={event.id} className="card mb-3">
                <div className="card-body">
                  <h5 className="card-title">{event.titulo}</h5>
                  <p className="card-text">{event.descricao}</p>
                  <p className="card-text">
                    <small className="text-muted">
                      Início: {" "}
                      {new Date(event.dataInicioEvento).toLocaleString('pt-BR')}
                    </small>
                  </p>
                  <p className="card-text">
                    <small className="text-muted">
                      Fim: {" "}
                      {new Date(event.dataFimEvento).toLocaleString('pt-BR')}
                    </small>
                  </p>
                  <p className="card-text">Preço: R${event.preco}</p>
                  <p className="card-text">
                    Total de Ingressos: {event.totalIngressos}
                  </p>
                  <button
                    className="btn btn-success"
                    onClick={() => handleShowModal(event.id)}
                  >
                    Comprar
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {showModal && (
          <>
            <div
              className="modal-backdrop show"
              onClick={handleCloseModal}
            ></div>
            <div
              className="modal"
              tabIndex={-1}
              role="dialog"
              style={{ display: "block" }}
            >
              <div className="modal-dialog" role="document">
                <div className="modal-content">
                  <div className="modal-header">
                    <h5 className="modal-title">Comprar Ingresso</h5>
                  </div>
                  <div className="modal-body">
                    <form>
                      <div className="form-group">
                        <label htmlFor="formQuantity">Quantidade</label>
                        <input
                          type="number"
                          className="form-control"
                          id="formQuantity"
                          value={quantity}
                          onChange={handleQuantityChange}
                          min="1"
                          max="3"
                          required
                        />
                      </div>
                    </form>
                  </div>
                  <div className="modal-footer">
                    <button
                      type="button"
                      className="btn btn-danger"
                      onClick={handleCloseModal}
                    >
                      Fechar
                    </button>
                    <button
                      type="button"
                      className="btn btn-success"
                      onClick={handleBookTicket}
                    >
                      Comprar
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </Auth>
  );
};

export default Events;
