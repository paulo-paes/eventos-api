import { Link, useNavigate } from "react-router-dom";

export const Navbar: React.FC = () => {
  const navigate = useNavigate()
  return (
    <>
      <nav className="navbar navbar-expand-lg bg-body-tertiary">
        <div className="container-fluid">
        <span className="navbar-brand mb-0 h1">Eventos</span>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNavAltMarkup"
            aria-controls="navbarNavAltMarkup"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div className="navbar-nav">
              <Link className="nav-link" aria-current="page" to="/events">
                Inicio
              </Link>
              <Link className="nav-link" to="/orders">
                Pedidos
              </Link>
              <Link className="nav-link" to="/create-event">
                Criar evento
              </Link>
              <a className="nav-link" aria-disabled="true" href="#"
                onClick={(e) => {
                  e.preventDefault()
                  localStorage.clear()
                  navigate('/')
                }}>
                Logout
              </a>
            </div>
          </div>
        </div>
      </nav>
    </>
  );
};
